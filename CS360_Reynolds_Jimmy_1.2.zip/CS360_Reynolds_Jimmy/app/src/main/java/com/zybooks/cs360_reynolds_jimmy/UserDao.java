package com.zybooks.cs360_reynolds_jimmy;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

// DAO interface for user authentication
@Dao
public interface UserDao {

    // Login query: returns user if credentials match
    @Query("SELECT * FROM users WHERE username = :username")
    UserEntity getUserByUsername(String username);

    // Login query with password check
    @Query("SELECT * FROM users WHERE username = :username AND password = :password LIMIT 1")
    UserEntity login(String username, String password);

    // Inserts a new user into the database
    @Insert
    void register(UserEntity user);
}
