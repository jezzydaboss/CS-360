package com.zybooks.cs360_reynolds_jimmy;

import android.app.Application;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

// Repository layer for user-related DB operations
public class UserRepository {
    private final UserDao userDao;
    private final Executor databaseExecutor; // Reusing the background executor

    public UserRepository(UserDao userDao, Executor databaseExecutor) {
        this.userDao = userDao;
        this.databaseExecutor = databaseExecutor;
    }

    /**
     * Executes the login query on a background thread.
     * @param username The username to check.
     * @param password The password to check.
     * @param callback The function to execute on the result (UserEntity or null).
     */
    public void login(String username, String password, Consumer<UserEntity> callback) {
        // This entire block now runs on the background thread
        databaseExecutor.execute(() -> {
            UserEntity user = userDao.login(username, password);

            // Execute the callback with the result. The caller (e.g., ViewModel/Activity)
            // is responsible for moving the callback logic back to the main thread if needed.
            callback.accept(user);
        });
    }

    // Register method (remains on background thread)
    public void register(UserEntity user) {
        databaseExecutor.execute(() -> userDao.register(user));
    }

    public void getUserByUsername(String username, Consumer<UserEntity> callback) {
        databaseExecutor.execute(() -> {
            // ASSUMPTION: userDao now has a getUserByUsername method
            UserEntity user = userDao.getUserByUsername(username);
            callback.accept(user);
        });
    }}