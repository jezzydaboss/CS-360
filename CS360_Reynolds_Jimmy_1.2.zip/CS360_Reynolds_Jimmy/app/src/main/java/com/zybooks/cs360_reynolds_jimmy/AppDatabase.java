package com.zybooks.cs360_reynolds_jimmy;
import androidx.room.Database;
import android.content.Context;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// Central Room database configuration for the app
@Database(entities = {UserEntity.class, InventoryItemEntity.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    // DAO accessors
    public abstract UserDao userDao();
    public abstract ItemDao itemDao();

    // Singleton instance to prevent multiple DB objects
    private static volatile AppDatabase INSTANCE;

    // Thread pool for background DB operations
    static final ExecutorService databaseWriteExecutor = Executors.newFixedThreadPool(4);

    // Returns the singleton DB instance
    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                        AppDatabase.class, "warehouse_db").build();
            }
        }
        return INSTANCE;
    }
}