package com.zybooks.cs360_reynolds_jimmy;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

// Activity for user login and registration
public class LoginActivity extends AppCompatActivity {
    private EditText usernameInput, passwordInput;
    private Button loginButton;
    private UserRepository userRepo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameInput = findViewById(R.id.usernameField);
        passwordInput = findViewById(R.id.passwordField);
        loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        AppDatabase db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "warehouse-db").build();
        UserDao userDao = db.userDao();
        Executor executor = Executors.newSingleThreadExecutor();
        userRepo = new UserRepository(userDao, executor);

        // ✅ Create Account Button Logic
        createAccountButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both username and password.", Toast.LENGTH_SHORT).show();
                return;
            }

            userRepo.getUserByUsername(username, existingUser -> {
                runOnUiThread(() -> {
                    if (existingUser != null) {
                        Toast.makeText(this, "Username already exists. Try a different one.", Toast.LENGTH_SHORT).show();
                    } else {
                        UserEntity newUser = new UserEntity(username, password);
                        userRepo.register(newUser);
                        Toast.makeText(this, "Account created! You can now log in.", Toast.LENGTH_LONG).show();
                    }
                });
            });
        });

        // ✅ Login Button Logic
        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both username and password.", Toast.LENGTH_SHORT).show();
                return;
            }

            userRepo.getUserByUsername(username, existingUser -> {
                if (existingUser != null) {
                    userRepo.login(username, password, loggedInUser -> {
                        runOnUiThread(() -> {
                            if (loggedInUser != null) {
                                startActivity(new Intent(this, InventoryActivity.class));
                                finish();
                            } else {
                                Toast.makeText(this, "Invalid username or password.", Toast.LENGTH_SHORT).show();
                            }
                        });
                    });
                } else {
                    UserEntity newUser = new UserEntity(username, password);
                    userRepo.register(newUser);
                    runOnUiThread(() -> {
                        Toast.makeText(this, "Account created! You are now logged in.", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(this, InventoryActivity.class));
                        finish();
                    });
                }
            });
        });
    }
}
