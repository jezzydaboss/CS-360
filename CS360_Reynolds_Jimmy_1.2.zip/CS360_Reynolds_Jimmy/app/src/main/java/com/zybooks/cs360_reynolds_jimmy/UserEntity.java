package com.zybooks.cs360_reynolds_jimmy;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// Defines the User table for login and registration
// Room entity representing a user account
@Entity(tableName = "users")
public class UserEntity {
    @PrimaryKey(autoGenerate = true) // Auto-incremented ID
    public int id;

    public String username; // Username for login
    public String password; // Password for login

    public UserEntity(String username, String password) {
        this.username = username;
        this.password = password;
    }
}